import React from 'react';
import './HomePage.css';
import Hero from './Hero';

const HomePage = () => {
    return (
        <div className="homePage">
            <Hero></Hero>
        </div>
    );
};

export default HomePage;