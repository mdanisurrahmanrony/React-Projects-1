# Doctor's Portal
React Doctor's Portal - Doctor's Appointment App with Admin Panel

[Visit Live Website](https://doctors-portal-ph-m36.web.app/ "Doctor's Portal - Doctor's Appointment App with Admin Panel")

![Screenshot](https://i.ibb.co/T41RPZG/r2.png "Doctor's Portal Appointment Booking")

### Project Features:
-	Booking Appointment with Calendar Date
-	Doctors Panel for Patient Management
-	Cloud DB, Material UI Implemented

### Technology Used:
- React
- Node
- Express
- Mongo
- Firebase
- Heroku
