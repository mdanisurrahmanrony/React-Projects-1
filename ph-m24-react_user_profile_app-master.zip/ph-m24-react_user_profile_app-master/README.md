# Social Profile - Connect Friend's 
React Social Profile App - Get connected with friends & calculate salaries

[Visit Live Website](https://lucid-goldstine-e3d29b.netlify.app/ "React Social Profile App")

![Screenshot](https://i.ibb.co/mXQ959X/r4.png "React Social Profile App")

### Project Features:
-	React SPA
-	React Multiple Component
-	Dynamic Data Loading


### Technology Used:
- React
- Netlify
