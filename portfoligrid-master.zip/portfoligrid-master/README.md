# PortfoliGrid
A Bootstrap 4 Portfolio Website

[Visit Live Website](https://rrahool.github.io/portfoligrid/src/index.html "PortfoliGrid - Portfolio Website")

![Screenshot](https://i.ibb.co/x1ssDNk/r5.png "PortfoliGrid - Portfolio Website")

### Project Features:

Multi-section Personal Portfolio Portal using only Bootstrap 4. Implemented Project Showcase & Contact Form.

### Technology Used:
- Bootstrap 4
- HTML
- CSS
