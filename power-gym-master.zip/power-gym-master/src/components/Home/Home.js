import React from 'react';
import TopBanner from '../TopBanner/TopBanner';

const Home = () => {
    return (
        <div>
            <TopBanner/>
        </div>
    );
};

export default Home;