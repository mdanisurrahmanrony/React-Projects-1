# Red Onion - Food Order App
React Red Onion Food Ordering App with Node-Mongo

[Visit Live Website](https://ph-m35-red-onion-w-nodemongo.firebaseapp.com/ "Red Onion - React Food Order App")

![Screenshot](https://i.ibb.co/JyxCF88/r1.png "Red Onion Banner")

### Project Features:
- Cloud Database Integrated
-	Payment Gateway Integrated
-	Firebase Authentication

### Technology:
- React
- Node
- Express
- Mongo
- Firebase
- Heroku
