# ema-john simple - E-commerce App
An amazon clone - React E-commerce App with Node-Mongo

[Visit Live Website](https://ema-john-rrahool.web.app/ " ema-john simple - React E-commerce App")

![Screenshot](https://i.ibb.co/Jy3rm8C/r3.png "ema-john E-commerce App")

### Project Features:
-	Full featured shopping cart
-	MERN Stack + Firebase Authentication 
-	Mongo Atlas Database (Cloud)

### Technology Used:
- React
- Node
- Express
- Mongo
- Firebase
- Heroku
