const firebaseConfig = {
    apiKey: "AIzaSyC747IyAuaH2CGPBzxCizuXrzU1W-JIk8g",
    authDomain: "ema-john-rrahool.firebaseapp.com",
    databaseURL: "https://ema-john-rrahool.firebaseio.com",
    projectId: "ema-john-rrahool",
    storageBucket: "ema-john-rrahool.appspot.com",
    messagingSenderId: "728582927379",
    appId: "1:728582927379:web:ce5ea0e5e2f8eee5f43be6"
  };

  export default firebaseConfig;