import React from 'react';

const NotFound = () => {
    return (
        <div>
            <h1>Sorry, Page not Found</h1>
            <h2>404 Error!!!</h2>
        </div>
    );
};

export default NotFound;